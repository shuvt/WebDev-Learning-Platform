<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name'    => trim($_POST['name'] ?? ''),
        'address' => trim($_POST['address'] ?? '') ?: null,
    ];
    saveRecord('Publishers', $data, $id, ['name'], 'Издательство', 'publishers.php');
}

if ($action === 'delete' && $id) {
    deleteRecord('Publishers', $id, 'Издательство удалено', 'Нельзя удалить: есть связанные книги', 'publishers.php');
}

if ($action === 'add' || $action === 'edit') {
    $pub = $id ? row("SELECT * FROM Publishers WHERE id=?", [$id]) : ['id'=>0,'name'=>'','address'=>''];
    pageTop($id ? 'Редактировать издательство' : 'Добавить издательство', 'publishers');
    echo getFlash();
    breadcrumb(['publishers.php' => 'Издательства', '' => $id ? 'Редактировать' : 'Добавить']);
    
    $fields = [
        ['label'=>'Название', 'type'=>'text', 'name'=>'name', 'value'=>$pub['name'], 'required'=>true, 'attrs'=>'maxlength="200"', 'full'=>true],
        ['label'=>'Адрес', 'type'=>'text', 'name'=>'address', 'value'=>$pub['address'], 'attrs'=>'maxlength="300"', 'full'=>true],
    ];
    renderForm('', $fields, 'Сохранить', 'publishers.php');
    pageBottom();
    exit;
}

$search = trim($_GET['q'] ?? '');

if ($search) {
    $pubs = query("
        SELECT p.*, COUNT(b.id) AS book_count
        FROM Publishers p
        LEFT JOIN Books b ON b.publisher_id = p.id
        WHERE p.name LIKE ? OR p.address LIKE ?
        GROUP BY p.id
        ORDER BY p.name
    ", ["%$search%", "%$search%"]);
} else {
    $pubs = query("
        SELECT p.*, COUNT(b.id) AS book_count
        FROM Publishers p
        LEFT JOIN Books b ON b.publisher_id = p.id
        GROUP BY p.id
        ORDER BY p.name
    ");
}

pageTop('Издательства', 'publishers');
echo getFlash();

?>
<div class="table-card">
    <?php renderSearchBar($search, [], 'publishers.php?action=add');?>
    <table class="data-table">
        <thead>
            <tr><th>#</th><th>Название</th><th>Адрес</th><th>Книг</th><th>Действия</th></tr>
        </thead>
        <tbody>
        <?php if ($pubs): ?>
            <?php foreach ($pubs as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><strong><?= e($p['name']) ?></strong></td>
                <td><?= e($p['address'] ?? '—') ?></td>
                <td><strong><?= $p['book_count'] ?></strong></td>
                <td>
                    <a href="?action=edit&id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">✎</a>
                    <a href="?action=delete&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить издательство?')">✕</a>
                </td>
            </tr>
            <?php endforeach ?>
        <?php else: ?>
            <?php renderEmptyState(5, 'Издательств не найдено'); ?>
        <?php endif ?>
        </tbody>
    </table>
</div>
<?php pageBottom(); ?>
