<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

// ── СОХРАНЕНИЕ ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'first_name' => trim($_POST['first_name'] ?? ''),
        'last_name'  => trim($_POST['last_name'] ?? ''),
        'birth_date' => $_POST['birth_date'] ?: null,
        'country'    => trim($_POST['country'] ?? '') ?: null,
    ];
    saveRecord('Authors', $data, $id, ['first_name', 'last_name'], 'Автор', 'authors.php');
}

// ── УДАЛЕНИЕ ──
if ($action === 'delete' && $id) {
    deleteRecord('Authors', $id, 'Автор удалён', 'Нельзя удалить: есть связанные книги', 'authors.php');
}

// ── ФОРМА ──
if ($action === 'add' || $action === 'edit') {
    $author = $id ? row("SELECT * FROM Authors WHERE id=?", [$id]) : ['id'=>0,'first_name'=>'','last_name'=>'','birth_date'=>'','country'=>''];
    pageTop($id ? 'Редактировать автора' : 'Добавить автора', 'authors');
    echo getFlash();
    breadcrumb(['authors.php' => 'Авторы', '' => $id ? 'Редактировать' : 'Добавить']);
    
    $fields = [
        ['label'=>'Имя', 'type'=>'text', 'name'=>'first_name', 'value'=>$author['first_name'], 'required'=>true, 'attrs'=>'maxlength="100"'],
        ['label'=>'Фамилия', 'type'=>'text', 'name'=>'last_name', 'value'=>$author['last_name'], 'required'=>true, 'attrs'=>'maxlength="100"'],
        ['label'=>'Дата рождения', 'type'=>'date', 'name'=>'birth_date', 'value'=>$author['birth_date']],
        ['label'=>'Страна', 'type'=>'text', 'name'=>'country', 'value'=>$author['country'], 'attrs'=>'maxlength="100"'],
    ];
    renderForm('', $fields, 'Сохранить', 'authors.php');
    pageBottom();
    exit;
}

// ── СПИСОК ──
$search = trim($_GET['q'] ?? '');

if ($search) {
    $authors = query("
        SELECT * FROM Authors 
        WHERE CONCAT(first_name, ' ', last_name) LIKE ? OR country LIKE ?
        ORDER BY last_name
    ", ["%$search%", "%$search%"]);
} else {
    $authors = query("SELECT * FROM Authors ORDER BY last_name");
}

pageTop('Авторы', 'authors');
echo getFlash();

?>
<div class="table-card">
    <?php renderSearchBar($search, [], 'authors.php?action=add');?>
    <table class="data-table">
        <thead>
            <tr><th>#</th><th>Фамилия</th><th>Имя</th><th>Дата рождения</th><th>Страна</th><th>Действия</th></tr>
        </thead>
        <tbody>
        <?php if ($authors): foreach ($authors as $a): ?>
            <tr>
                <td class="td-muted"><?= $a['id'] ?></td>
                <td><strong><?= e($a['last_name']) ?></strong></td>
                <td><?= e($a['first_name']) ?></td>
                <td><?= dateRu($a['birth_date']) ?></td>
                <td><?= e($a['country'] ?? '—') ?></td>
                <td>
                    <a href="?action=edit&id=<?= $a['id'] ?>" class="btn btn-outline btn-sm">✎</a>
                    <a href="?action=delete&id=<?= $a['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить автора?')">✕</a>
                </td>
            </tr>
        <?php endforeach; else: renderEmptyState(6, 'Авторы не найдены'); endif; ?>
        </tbody>
    </table>
</div>
<?php pageBottom(); ?>