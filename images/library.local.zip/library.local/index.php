<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$stats = getStats();

// Последние выдачи
$recentBorrows = query("
    SELECT br.borrow_date, br.due_date, br.return_date,
           CONCAT(u.first_name, ' ', u.last_name) AS user_name,
           b.title
    FROM Borrow_records br
    JOIN Users u        ON br.user_id      = u.id
    JOIN Book_copies bc ON br.book_copy_id = bc.id
    JOIN Books b        ON bc.book_id      = b.id
    ORDER BY br.borrow_date DESC
    LIMIT 8
");

// Просроченные выдачи
$overdueList = query("
    SELECT CONCAT(u.first_name, ' ', u.last_name) AS user_name,
           b.title, br.due_date
    FROM Borrow_records br
    JOIN Users u        ON br.user_id      = u.id
    JOIN Book_copies bc ON br.book_copy_id = bc.id
    JOIN Books b        ON bc.book_id      = b.id
    WHERE br.return_date IS NULL AND br.due_date < CURDATE()
    ORDER BY br.due_date ASC
    LIMIT 5
");

// Популярные книги
$popularBooks = query("
    SELECT b.title, a.last_name, COUNT(br.id) AS cnt
    FROM Books b
    JOIN Authors a ON b.author_id = a.id
    JOIN Book_copies bc ON bc.book_id = b.id
    JOIN Borrow_records br ON br.book_copy_id = bc.id
    GROUP BY b.id
    ORDER BY cnt DESC
    LIMIT 3
");

pageTop('Главная', 'index');
?>

<!-- Статистика -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= $stats['books'] ?></div>
        <div class="stat-label">Книг</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $stats['authors'] ?></div>
        <div class="stat-label">Авторов</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $stats['users'] ?></div>
        <div class="stat-label">Читателей</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $stats['copies'] ?></div>
        <div class="stat-label">Экземпляров</div>
    </div>
</div>

<!-- Виджеты -->
<div class="dash-row">

    <!-- Последние выдачи -->
    <div class="widget">
        <div class="widget-head">Последние выдачи</div>
        <div class="widget-body">
            <?php if ($recentBorrows): ?>
                <?php foreach ($recentBorrows as $r): ?>
                <div class="widget-row">
                    <div>
                        <div class="widget-row-title"><?= e($r['title']) ?></div>
                        <div class="widget-row-sub"><?= e($r['user_name']) ?> · <?= dateRu($r['borrow_date']) ?></div>
                    </div>
                    <?php if ($r['return_date']): ?>
                        <span class="badge green">Вернул</span>
                    <?php elseif ($r['due_date'] < date('Y-m-d')): ?>
                        <span class="badge red">Просрочена</span>
                    <?php else: ?>
                        <span class="badge blue">Активна</span>
                    <?php endif ?>
                </div>
                <?php endforeach ?>
            <?php else: ?>
                <div class="empty"><div class="empty-text">Выдач пока нет</div></div>
            <?php endif ?>
        </div>
    </div>

    <div class="right-col">

        <!-- Просроченные -->
        <div class="widget">
            <div class="widget-head" style="color:var(--red)">Просроченные</div>
            <div class="widget-body">
                <?php if ($overdueList): ?>
                    <?php foreach ($overdueList as $r): ?>
                    <div class="widget-row">
                        <div>
                            <div class="widget-row-title"><?= e($r['title']) ?></div>
                            <div class="widget-row-sub"><?= e($r['user_name']) ?></div>
                        </div>
                        <div class="widget-row-val widget-row-red"><?= dateRu($r['due_date']) ?></div>
                    </div>
                    <?php endforeach ?>
                <?php else: ?>
                    <div class="widget-row"><span style="color:var(--green)">Просроченных нет!</span></div>
                <?php endif ?>
            </div>
        </div>

        <!-- Популярные -->
        <div class="widget">
            <div class="widget-head">Популярные книги</div>
            <div class="widget-body">
                <?php foreach ($popularBooks as $r): ?>
                <div class="widget-row">
                    <div>
                        <div class="widget-row-title"><?= e($r['title']) ?></div>
                        <div class="widget-row-sub"><?= e($r['last_name']) ?></div>
                    </div>
                    <div class="widget-row-val"><?= $r['cnt'] ?> раз</div>
                </div>
                <?php endforeach ?>
                <?php if (!$popularBooks): ?>
                    <div class="empty"><div class="empty-text">Нет данных</div></div>
                <?php endif ?>
            </div>
        </div>

    </div>
</div>

<?php pageBottom() ?>
