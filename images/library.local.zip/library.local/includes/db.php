<?php
// ПОДКЛЮЧЕНИЕ К БД
define('DB_HOST', 'MySQL-8.2');  
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'library_db2');

// Создаём одно подключение PDO на весь запрос
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}

// ФУНКЦИИ ДЛЯ РАБОТЫ С БД
// Получить все строки: query("SELECT * FROM Books WHERE genre=?", [$genre])
// используется например для поиска по жанрам, на выход получаем много строк
function query(string $sql, array $params = []): array {
    $stmt = db()->prepare($sql); // соединение с базой и подготовка запроса
    $stmt->execute($params);     // вставляет пропущенной значение в запрос
    return $stmt->fetchAll();
}

// Получить одну строку: row("SELECT * FROM Books WHERE id=?", [$id])
// например информация о книги с конкретным айди
function row(string $sql, array $params = []): array|false {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch();
}

// Получить одно значение: val("SELECT COUNT(*) FROM Books")
// используется для получения общего кол-ва читателей, книг и т.д. , одно число
function val(string $sql, array $params = []): mixed {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

// Выполнить INSERT/UPDATE/DELETE: run("DELETE FROM Books WHERE id=?", [$id])
// выполняет действия, например, обновление книги
function run(string $sql, array $params = []): void {
    db()->prepare($sql)->execute($params);
}
