<?php
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ

// Защита от поломки разметки страницы из-за спец символов
function e(?string $str): string {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// Форматирование даты: '2024-01-15' -> '15.01.2024'
function dateRu(?string $date): string {
    if (!$date) return '—';
    return date('d.m.Y', strtotime($date));
}

// Редирект на другую страницу
function go(string $url): never {
    header("Location: $url");
    exit;
}

// Сохранить flash-сообщение
function flash(string $type, string $text): void {
    $_SESSION['flash'] = compact('type', 'text');
}

// Получить и удалить flash-сообщение
function getFlash(): string {
    if (empty($_SESSION['flash'])) return '';
    ['type' => $type, 'text' => $text] = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return '<div class="flash flash-' . e($type) . '">' . e($text) . '</div>';
}

// Статус экземпляра книги -> перевод
function statusLabel(string $status): string {
    return match($status) {
        'available' => '<span class="badge green">Доступна</span>',
        'borrowed'  => '<span class="badge blue">Выдана</span>',
        'damaged'   => '<span class="badge orange">Повреждена</span>',
        'lost'      => '<span class="badge red">Утеряна</span>',
        default     => '<span class="badge">?</span>',
    };
}

// Статистика для главной страницы
function getStats(): array {
    return [
        'books'     => val("SELECT COUNT(*) FROM Books"),
        'authors'   => val("SELECT COUNT(*) FROM Authors"),
        'users'     => val("SELECT COUNT(*) FROM Users"),
        'copies'    => val("SELECT COUNT(*) FROM Book_copies"),
    ];
}

function saveRecord(string $table, array $data, int $id, array $required, string $successMsg, string $redirect): void {
    // Проверка обязательных полей
    foreach ($required as $field) {
        if (empty($data[$field])) {
            flash('error', 'Заполните обязательные поля');
            go($redirect);
        }
    }

    if ($id) {
        // UPDATE
        $setParts = [];
        $values = [];
        foreach ($data as $field => $value) {
            if ($field !== 'id') {
                $setParts[] = "$field=?";
                $values[] = $value;
            }
        }
        $values[] = $id;
        run("UPDATE $table SET " . implode(', ', $setParts) . " WHERE id=?", $values);
        flash('success', $successMsg . ' обновлён(а)');
    } else {
        // INSERT
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($data), '?');
        run("INSERT INTO $table (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")", array_values($data));
        flash('success', $successMsg . ' добавлен(а)');
    }
    go($redirect);
}


function deleteRecord(string $table, int $id, string $successMsg, string $errorMsg, string $redirect): void {
    try {
        run("DELETE FROM $table WHERE id=?", [$id]);
        flash('success', $successMsg);
    } catch (PDOException $e) {
        flash('error', $errorMsg);
    }
    go($redirect);
}

function breadcrumb(array $items): void {
    $last = array_pop($items);
    echo '<div class="breadcrumb">';
    foreach ($items as $url => $label) {
        echo '<a href="' . $url . '">' . e($label) . '</a> <span class="bc-sep">›</span> ';
    }
    echo '<span>' . e($last) . '</span>';
    echo '</div>';
}

function renderForm(string $action, array $fields, string $submitLabel, string $cancelUrl): void {
    ?>
    <div class="form-card">
        <form method="post" action="<?= $action ?>">
            <div class="form-grid">
                <?php foreach ($fields as $f): 
                    $fullClass = ($f['full'] ?? false) ? 'full' : '';
                    $value = $f['value'] ?? '';
                    $required = ($f['required'] ?? false) ? 'required' : '';
                ?>
                <div class="form-group <?= $fullClass ?>">
                    <label><?= e($f['label']) ?> <?= $required ? '*' : '' ?></label>
                    <?php if ($f['type'] === 'select'): ?>
                        <select name="<?= $f['name'] ?>" <?= $required ?>>
                            <?php foreach ($f['options'] as $optVal => $optLabel): ?>
                            <option value="<?= $optVal ?>" <?= (string)$value === (string)$optVal ? 'selected' : '' ?>><?= e($optLabel) ?></option>
                            <?php endforeach ?>
                        </select>
                    <?php elseif ($f['type'] === 'number'): ?>
                        <input type="number" name="<?= $f['name'] ?>" value="<?= e($value) ?>" <?= $required ?> <?= $f['attrs'] ?? '' ?>>
                    <?php elseif ($f['type'] === 'date'): ?>
                        <input type="date" name="<?= $f['name'] ?>" value="<?= e($value) ?>" <?= $required ?>>
                    <?php else: ?>
                        <input type="<?= $f['type'] ?>" name="<?= $f['name'] ?>" value="<?= e($value) ?>" <?= $required ?> <?= $f['attrs'] ?? '' ?>>
                    <?php endif ?>
                </div>
                <?php endforeach ?>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $submitLabel ?></button>
                <a href="<?= $cancelUrl ?>" class="btn btn-outline">Отмена</a>
            </div>
        </form>
    </div>
    <?php
}

function renderSearchBar(string $searchValue, array $filters = [], string $addUrl = '', string $addLabel = '+ Добавить'): void {
?>
<div class="table-toolbar">
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <form method="get" style="display:flex;gap:8px">
            <input type="text" name="q" class="search-input" placeholder="Поиск…" value="<?= e($searchValue) ?>">
            <?php foreach ($filters as $filter): ?>
                <?php if (isset($filter['options'])): ?>
                <select name="<?= e($filter['name']) ?>" class="filter-select">
                    <?php foreach ($filter['options'] as $val => $label): ?>
                    <option value="<?= e($val) ?>" <?= ($filter['value'] ?? '') == $val ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach ?>
                </select>
                <?php endif ?>
            <?php endforeach ?>
            <button type="submit" class="btn btn-outline btn-sm">Найти</button>
        </form>
        <?php if ($addUrl): ?>
        <a href="<?= $addUrl ?>" class="btn btn-primary btn-sm"><?= e($addLabel) ?></a>
        <?php endif ?>
    </div>
</div>
<?php
}

function renderEmptyState(int $colspan, string $text = 'Ничего не найдено'): void {
    echo '<tr><td colspan="' . $colspan . '"><div class="empty">';
    echo '<div class="empty-text">' . $text . '</div></div></td></tr>';
}

