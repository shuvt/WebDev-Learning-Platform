<?php
function pageTop(string $title, string $active = ''): void {
    $nav = [
        'index'      => ['index.php', 'Главная'],
        'books'      => ['books.php', 'Книги'],
        'authors'    => ['authors.php', 'Авторы'],
        'publishers' => ['publishers.php', 'Издательства'],
        'users'      => ['users.php', 'Читатели'],
        'copies'     => ['copies.php', 'Экземпляры'],
        'borrows'    => ['borrows.php', 'Выдача'],
    ];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= e($title) ?> — Библиотека</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<aside class="sidebar">
    <div class="logo">
        <span class="logo-icon" style="filter: brightness(0) invert(1);">🕮</span>
        <div>
            <div class="logo-name">Библиотека</div>
            <div class="logo-sub">Система управления</div>
        </div>
    </div>
    <nav>
        <?php foreach ($nav as $key => [$url, $label]): ?>
        <a href="<?= $url ?>" class="nav-link <?= $active === $key ? 'active' : '' ?>">
            <?= $label ?>
        </a>
        <?php endforeach ?>
    </nav>
</aside>
<div class="page">
    <header class="topbar">
        <h1><?= e($title) ?></h1>
    </header>
    <main class="main">
<?php
}

function pageBottom(): void {
?>
    </main>
</div>
</body>
</html>
<?php
}