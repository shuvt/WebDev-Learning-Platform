<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

$genres = query("SELECT DISTINCT genre FROM Books WHERE genre IS NOT NULL ORDER BY genre");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title'            => trim($_POST['title'] ?? ''),
        'author_id'        => (int)($_POST['author_id'] ?? 0),
        'publisher_id'     => (int)($_POST['publisher_id'] ?? 0),
        'genre'            => trim($_POST['genre'] ?? '') ?: null,
        'page_count'       => (int)($_POST['page_count'] ?? 0) ?: null,
        'age_limit'        => (int)($_POST['age_limit'] ?? 0),
        'publication_date' => $_POST['publication_date'] ?: null,
    ];
    saveRecord('Books', $data, $id, ['title', 'author_id', 'publisher_id'], 'Книга', 'books.php');
}

if ($action === 'delete' && $id) {
    deleteRecord('Books', $id, 'Книга удалена', 'Нельзя удалить: есть связанные экземпляры', 'books.php');
}

if ($action === 'add' || $action === 'edit') {
    // Загружаем данные книги, если редактируем
    $book = $id ? row("SELECT * FROM Books WHERE id=?", [$id]) : [
        'id' => 0,
        'title' => '',
        'author_id' => 0,
        'publisher_id' => 0,
        'genre' => '',
        'page_count' => '',
        'age_limit' => 0,
        'publication_date' => ''
    ];
    
    // Получаем списки для выпадающих меню
    $authors    = query("SELECT id, CONCAT(first_name, ' ', last_name) AS name FROM Authors ORDER BY last_name");
    $publishers = query("SELECT id, name FROM Publishers ORDER BY name");
    
    // Преобразуем массивы в формат, удобный для renderForm (options)
    $authorOptions = ['' => '— выберите автора —'];
    foreach ($authors as $a) {
        $authorOptions[$a['id']] = $a['name'];
    }
    
    $publisherOptions = ['' => '— выберите издательство —'];
    foreach ($publishers as $p) {
        $publisherOptions[$p['id']] = $p['name'];
    }
    
    $ageOptions = [0 => '0+', 6 => '6+', 12 => '12+', 16 => '16+', 18 => '18+'];
    
    pageTop($id ? 'Редактировать книгу' : 'Добавить книгу', 'books');
    echo getFlash();
    breadcrumb(['books.php' => 'Книги', '' => $id ? 'Редактировать' : 'Добавить']);
    
    $fields = [
        ['label'=>'Название', 'type'=>'text', 'name'=>'title', 'value'=>$book['title'], 'required'=>true, 'attrs'=>'maxlength="300"', 'full'=>true],
        ['label'=>'Автор', 'type'=>'select', 'name'=>'author_id', 'value'=>$book['author_id'], 'required'=>true, 'options'=>$authorOptions],
        ['label'=>'Издательство', 'type'=>'select', 'name'=>'publisher_id', 'value'=>$book['publisher_id'], 'required'=>true, 'options'=>$publisherOptions],
        ['label'=>'Жанр', 'type'=>'text', 'name'=>'genre', 'value'=>$book['genre'], 'attrs'=>'maxlength="100" list="genres-list"'],
        ['label'=>'Дата публикации', 'type'=>'date', 'name'=>'publication_date', 'value'=>$book['publication_date']],
        ['label'=>'Количество страниц', 'type'=>'number', 'name'=>'page_count', 'value'=>$book['page_count'], 'attrs'=>'min="1"'],
        ['label'=>'Возрастное ограничение', 'type'=>'select', 'name'=>'age_limit', 'value'=>$book['age_limit'], 'options'=>$ageOptions],
    ];
    
    // Выводим datalist для поля "Жанр" – он будет доступен для автодополнения
    echo '<datalist id="genres-list">';
    foreach ($genres as $g) {
        echo '<option value="' . e($g['genre']) . '">';
    }
    echo '</datalist>';
    
    renderForm('', $fields, 'Сохранить', 'books.php');
    pageBottom();
    exit;
}

$search = trim($_GET['q'] ?? '');
$genreFilter = trim($_GET['genre'] ?? '');

$sql = "
    SELECT 
        b.*,
        CONCAT(a.first_name, ' ', a.last_name) AS author_name,
        p.name AS publisher_name,
        (SELECT COUNT(*) FROM Book_copies WHERE book_id = b.id) AS total_copies,
        (SELECT COUNT(*) FROM Book_copies WHERE book_id = b.id AND status = 'available') AS avail_copies
    FROM Books b
    JOIN Authors a ON b.author_id = a.id
    JOIN Publishers p ON b.publisher_id = p.id
";

// Добавляем условия поиска и фильтра
$where = [];
$params = [];

if ($search) {
    $where[] = "(b.title LIKE ? OR CONCAT(a.first_name, ' ', a.last_name) LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($genreFilter) {
    $where[] = "b.genre = ?";
    $params[] = $genreFilter;
}

if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " ORDER BY b.title";

$books = query($sql, $params);

pageTop('Книги', 'books');
echo getFlash();

// Готовим опции для фильтра по жанру
$genreOptions = ['' => 'Все жанры'];
foreach ($genres as $g) {
    $genreOptions[$g['genre']] = $g['genre'];
}

// Передаём в renderSearchBar массив с одним фильтром
$filters = [
    ['name' => 'genre', 'placeholder' => 'Все жанры', 'value' => $genreFilter, 'options' => $genreOptions]
];

?>
<div class="table-card">
    <?php renderSearchBar($search, $filters, 'books.php?action=add');?>
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th><th>Название</th><th>Автор</th><th>Издательство</th>
                <th>Жанр</th><th>Страниц</th><th>Возраст</th><th>Год</th>
                <th>Экз. / Доступно</th><th>Действия</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($books): foreach ($books as $b): ?>
            <tr>
                <td class="td-muted"><?= $b['id'] ?></td>
                <td><strong><?= e($b['title']) ?></strong></td>
                <td><?= e($b['author_name']) ?></td>
                <td><?= e($b['publisher_name']) ?></td>
                <td><?= e($b['genre'] ?? '—') ?></td>
                <td><?= $b['page_count'] ?? '—' ?></td>
                <td><?= $b['age_limit'] ?>+</td>
                <td><?= $b['publication_date'] ? date('Y', strtotime($b['publication_date'])) : '—' ?></td>
                <td><?= $b['total_copies'] ?> / <strong><?= $b['avail_copies'] ?></strong></td>
                <td style="display:flex;gap:6px">
                    <a href="?action=edit&id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">✎</a>
                    <a href="copies.php?book_id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">Экземпляры</a>
                    <a href="?action=delete&id=<?= $b['id'] ?>" class="btn btn-danger btn-sm" 
                    onclick="return confirm('Удалить книгу «<?= e(addslashes($b['title'])) ?>»?')">✕</a>
                </td>
            </tr>
        <?php endforeach; else: renderEmptyState(10, 'Книги не найдены'); endif; ?>
        </tbody>
    </table>
</div>
<?php pageBottom(); ?>
