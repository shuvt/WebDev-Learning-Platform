<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'first_name'        => trim($_POST['first_name'] ?? ''),
        'last_name'         => trim($_POST['last_name'] ?? ''),
        'registration_date' => $_POST['registration_date'] ?: date('Y-m-d'),
        'birth_date'        => $_POST['birth_date'] ?: null,
    ];
    saveRecord('Users', $data, $id, ['first_name', 'last_name'], 'Читатель', 'users.php');
}

if ($action === 'delete' && $id) {
    deleteRecord('Users', $id, 'Читатель удалён', 'Нельзя удалить: есть записи о выдаче', 'users.php');
}

if ($action === 'view' && $id) {
    // Загружаем данные читателя
    $user = row("SELECT * FROM Users WHERE id=?", [$id]);
    if (!$user) {
        flash('error', 'Читатель не найден');
        go('users.php');
    }
    
    // Загружаем историю выдач
    $borrows = query("
        SELECT br.borrow_date, br.due_date, br.return_date, b.title
        FROM Borrow_records br
        JOIN Book_copies bc ON br.book_copy_id = bc.id
        JOIN Books b        ON bc.book_id      = b.id
        WHERE br.user_id = ?
        ORDER BY br.borrow_date DESC
    ", [$id]);
    
    pageTop($user['first_name'] . ' ' . $user['last_name'], 'users');
    echo getFlash();
    breadcrumb(['users.php' => 'Читатели', '' => $user['first_name'] . ' ' . $user['last_name']]);
    ?>
    <div class="user-card">
        <div class="user-avatar"><?= mb_substr($user['first_name'], 0, 1) ?></div>
        <div>
            <div class="user-name"><?= e($user['first_name'] . ' ' . $user['last_name']) ?></div>
            <div class="user-meta">
                Зарегистрирован: <?= dateRu($user['registration_date']) ?>
                <?= $user['birth_date'] ? ' · Дата рождения: ' . dateRu($user['birth_date']) : '' ?>
            </div>
            <div style="margin-top:10px;display:flex;gap:8px">
                <a href="?action=edit&id=<?= $id ?>" class="btn btn-outline btn-sm">Редактировать</a>
                <a href="borrows.php?action=add&user_id=<?= $id ?>" class="btn btn-primary btn-sm">Выдать книгу</a>
            </div>
        </div>
    </div>
    <div class="table-card">
        <div class="widget-head" style="padding:14px 18px">История выдач (<?= count($borrows) ?>)</div>
        <table class="data-table">
            <thead>
                <tr><th>Книга</th><th>Выдана</th><th>Срок</th><th>Возвращена</th><th>Статус</th></tr>
            </thead>
            <tbody>
            <?php if ($borrows): ?>
                <?php foreach ($borrows as $r): 
                    $overdue = !$r['return_date'] && $r['due_date'] < date('Y-m-d');
                ?>
                <tr class="<?= $overdue ? 'overdue' : '' ?>">
                    <td><?= e($r['title']) ?></td>
                    <td><?= dateRu($r['borrow_date']) ?></td>
                    <td><?= dateRu($r['due_date']) ?></td>
                    <td><?= dateRu($r['return_date']) ?></td>
                    <td>
                        <?php if ($r['return_date']): ?>
                            <span class="badge green">Возвращена</span>
                        <?php elseif ($overdue): ?>
                            <span class="badge red">Просрочена</span>
                        <?php else: ?>
                            <span class="badge blue">Активна</span>
                        <?php endif ?>
                    </td>
                </tr>
                <?php endforeach ?>
            <?php else: ?>
                <tr><td colspan="5"><div class="empty"><div class="empty-text">Выдач не было</div></div></td></tr>
            <?php endif ?>
            </tbody>
        </table>
    </div>
    <?php
    pageBottom();
    exit;
}

if ($action === 'add' || $action === 'edit') {
    $user = $id ? row("SELECT * FROM Users WHERE id=?", [$id]) : ['id'=>0,'first_name'=>'','last_name'=>'','registration_date'=>date('Y-m-d'),'birth_date'=>''];
    pageTop($id ? 'Редактировать читателя' : 'Добавить читателя', 'users');
    echo getFlash();
    breadcrumb(['users.php' => 'Читатели', '' => $id ? 'Редактировать' : 'Добавить']);
    
    $fields = [
        ['label'=>'Имя', 'type'=>'text', 'name'=>'first_name', 'value'=>$user['first_name'], 'required'=>true, 'attrs'=>'maxlength="100"'],
        ['label'=>'Фамилия', 'type'=>'text', 'name'=>'last_name', 'value'=>$user['last_name'], 'required'=>true, 'attrs'=>'maxlength="100"'],
        ['label'=>'Дата регистрации', 'type'=>'date', 'name'=>'registration_date', 'value'=>$user['registration_date']],
        ['label'=>'Дата рождения', 'type'=>'date', 'name'=>'birth_date', 'value'=>$user['birth_date']],
    ];
    renderForm('', $fields, 'Сохранить', 'users.php');
    pageBottom();
    exit;
}

$search = trim($_GET['q'] ?? '');

if ($search) {
    $users = query("
        SELECT * FROM Users
        WHERE CONCAT(first_name, ' ', last_name) LIKE ?
        ORDER BY last_name
    ", ["%$search%"]);
} else {
    $users = query("SELECT * FROM Users ORDER BY last_name");
}

pageTop('Читатели', 'users');
echo getFlash();

?>
<div class="table-card">
    <?php renderSearchBar($search, [], 'users.php?action=add'); ?>
    <table class="data-table">
        <thead>
            <tr><th>#</th><th>Фамилия</th><th>Имя</th><th>Дата рождения</th><th>Регистрация</th><th>Действия</th></tr>
        </thead>
        <tbody>
        <?php if ($users): foreach ($users as $u): ?>
            <tr>
                <td class="td-muted"><?= $u['id'] ?></td>
                <td><?= e($u['last_name']) ?></td>
                <td><?= e($u['first_name']) ?></td>
                <td><?= dateRu($u['birth_date']) ?></td>
                <td><?= dateRu($u['registration_date']) ?></td>
                <td style="display:flex;gap:6px">
                    <a href="?action=view&id=<?= $u['id'] ?>" class="btn btn-outline btn-sm">Карточка</a>
                    <a href="?action=edit&id=<?= $u['id'] ?>" class="btn btn-outline btn-sm">✎</a>
                    <a href="?action=delete&id=<?= $u['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить читателя?')">✕</a>
                </td>
            </tr>
        <?php endforeach; else: renderEmptyState(6, 'Читатели не найдены'); endif; ?>
        </tbody>
    </table>
</div>
<?php pageBottom(); ?>
