<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

if ($action === 'return' && $id) {
    // Получаем запись о выдаче и заодно book_copy_id
    $record = row("
        SELECT br.*, bc.id AS copy_id 
        FROM Borrow_records br 
        JOIN Book_copies bc ON br.book_copy_id = bc.id 
        WHERE br.id = ?
    ", [$id]);
    
    if ($record && !$record['return_date']) {
        // Устанавливаем дату возврата (сегодня)
        run("UPDATE Borrow_records SET return_date = CURDATE() WHERE id = ?", [$id]);
        // Возвращаем экземпляр в доступные
        run("UPDATE Book_copies SET status = 'available' WHERE id = ?", [$record['copy_id']]);
        flash('success', 'Книга отмечена как возвращённая');
    } else {
        flash('error', 'Ошибка: запись не найдена или книга уже возвращена');
    }
    go('borrows.php');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $copy_id = (int)($_POST['book_copy_id'] ?? 0);
    $borrow_date = $_POST['borrow_date'] ?: date('Y-m-d');
    $due_date    = $_POST['due_date'] ?? '';

    // Базовая проверка
    if (!$user_id || !$copy_id || !$due_date) {
        flash('error', 'Заполните все обязательные поля');
        go('borrows.php?action=add');
    }

    // Проверяем, что экземпляр доступен
    $status = val("SELECT status FROM Book_copies WHERE id = ?", [$copy_id]);
    if ($status !== 'available') {
        flash('error', 'Этот экземпляр недоступен для выдачи (уже выдан, повреждён или утерян)');
        go('borrows.php?action=add');
    }

    // Начинаем транзакцию (для согласованности данных)
    $pdo = db();
    try {
        $pdo->beginTransaction();
        
        // Вставляем запись о выдаче
        run("
            INSERT INTO Borrow_records (user_id, book_copy_id, borrow_date, due_date) 
            VALUES (?, ?, ?, ?)
        ", [$user_id, $copy_id, $borrow_date, $due_date]);
        
        // Обновляем статус экземпляра
        run("UPDATE Book_copies SET status = 'borrowed' WHERE id = ?", [$copy_id]);
        
        $pdo->commit();
        flash('success', 'Книга выдана');
    } catch (PDOException $e) {
        $pdo->rollBack();
        flash('error', 'Ошибка при выдаче. Попробуйте снова.');
    }
    
    go('borrows.php');
} 

if ($action === 'add') {
    // Получаем параметры для предзаполнения из GET (если есть)
    $preCopyId = (int)($_GET['copy_id'] ?? 0);
    $preUserId = (int)($_GET['user_id'] ?? 0);
    
    // Список читателей (ФИО)
    $users = query("SELECT id, CONCAT(first_name, ' ', last_name) AS name FROM Users ORDER BY last_name");
    // Список доступных экземпляров (с названием книги)
    $copies = query("
        SELECT bc.id, CONCAT(b.title, ' (экз. #', bc.id, ')') AS label
        FROM Book_copies bc
        JOIN Books b ON bc.book_id = b.id
        WHERE bc.status = 'available'
        ORDER BY b.title, bc.id
    ");
    
    $userOptions = ['' => '— выберите читателя —'];
    foreach ($users as $u) {
        $userOptions[$u['id']] = $u['name'];
    }
    
    $copyOptions = ['' => '— выберите экземпляр —'];
    foreach ($copies as $c) {
        $copyOptions[$c['id']] = $c['label'];
    }
    
    pageTop('Выдать книгу', 'borrows');
    echo getFlash();
    breadcrumb(['borrows.php' => 'Выдача', '' => 'Новая выдача']);
    
    $fields = [
        ['label' => 'Читатель', 'type' => 'select', 'name' => 'user_id', 'value' => $preUserId, 'required' => true, 'options' => $userOptions, 'full' => true],
        ['label' => 'Экземпляр книги', 'type' => 'select', 'name' => 'book_copy_id', 'value' => $preCopyId, 'required' => true, 'options' => $copyOptions, 'full' => true],
        ['label' => 'Дата выдачи', 'type' => 'date', 'name' => 'borrow_date', 'value' => date('Y-m-d')],
        ['label' => 'Срок возврата', 'type' => 'date', 'name' => 'due_date', 'value' => '', 'required' => true, 'attrs' => 'min="' . date('Y-m-d') . '"'],
    ];
    
    renderForm('', $fields, 'Выдать книгу', 'borrows.php');
    pageBottom();
    exit;
}

// Получаем параметры поиска и фильтра
$search = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';

// Формируем WHERE
$where = [];
$params = [];

if ($search) {
    $where[] = "(b.title LIKE ? OR CONCAT(u.first_name, ' ', u.last_name) LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($statusFilter === 'active') {
    $where[] = "br.return_date IS NULL";
} elseif ($statusFilter === 'returned') {
    $where[] = "br.return_date IS NOT NULL";
} elseif ($statusFilter === 'overdue') {
    $where[] = "br.return_date IS NULL AND br.due_date < CURDATE()";
}

$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Основной запрос
$borrows = query("
    SELECT 
        br.*,
        b.title,
        bc.id AS copy_id,
        CONCAT(u.first_name, ' ', u.last_name) AS user_name,
        u.id AS user_id
    FROM Borrow_records br
    JOIN Users u ON br.user_id = u.id
    JOIN Book_copies bc ON br.book_copy_id = bc.id
    JOIN Books b ON bc.book_id = b.id
    $w
    ORDER BY br.borrow_date DESC, br.id DESC
", $params);

pageTop('Записи о выдаче', 'borrows');
echo getFlash();

// Готовим фильтр по статусу
$statusOptions = [
    ''         => 'Все',
    'active'   => 'Активные',
    'overdue'  => 'Просроченные',
    'returned' => 'Возвращённые'
];
$filters = [['name' => 'status', 'value' => $statusFilter, 'options' => $statusOptions]];

?>

<div class="table-card">
    <?php renderSearchBar($search, $filters, 'borrows.php?action=add', 'Выдать книгу'); ?>
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th><th>Книга</th><th>Экз.</th><th>Читатель</th>
                <th>Выдана</th><th>Срок</th><th>Возвращена</th><th>Статус</th><th>Действия</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($borrows): foreach ($borrows as $r): 
            $overdue = !$r['return_date'] && $r['due_date'] < date('Y-m-d');
        ?>
            <tr class="<?= $overdue ? 'overdue' : '' ?>">
                <td class="td-muted"><?= $r['id'] ?></td>
                <td><?= e($r['title']) ?></td>
                <td class="td-muted">#<?= $r['copy_id'] ?></td>
                <td><a href="users.php?action=view&id=<?= $r['user_id'] ?>" style="text-decoration:none; color:var(--primary); font-weight:bold;" class="user-link"><?= e($r['user_name']) ?></a></td>
                <td><?= dateRu($r['borrow_date']) ?></td>
                <td><?= dateRu($r['due_date']) ?></td>
                <td><?= dateRu($r['return_date']) ?></td>
                <td>
                    <?php if ($r['return_date']): ?>
                        <span class="badge green">Возвращена</span>
                    <?php elseif ($overdue): ?>
                        <span class="badge red">Просрочена</span>
                    <?php else: ?>
                        <span class="badge blue">Активна</span>
                    <?php endif ?>
                </td>
                <td>
                    <?php if (!$r['return_date']): ?>
                        <a href="?action=return&id=<?= $r['id'] ?>" class="btn btn-primary btn-sm" onclick="return confirm('Отметить книгу как возвращённую?')">Вернуть</a>
                    <?php else: ?>
                        <span class="td-muted">Завершено</span>
                    <?php endif ?>
                </td>
            </tr>
        <?php endforeach; else: renderEmptyState(9, 'Записей не найдено'); endif; ?>
        </tbody>
    </table>
</div>

<?php pageBottom(); ?>
