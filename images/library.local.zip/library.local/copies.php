<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/helpers.php';
require_once 'includes/layout.php';

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

$bookFilter = (int)($_GET['book_id'] ?? 0);

$books = query("SELECT id, title FROM Books ORDER BY title");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id = (int)($_POST['book_id'] ?? 0);
    $status  = $_POST['status'] ?? 'available';
    $count   = max(1, min(50, (int)($_POST['count'] ?? 1)));

    if (!$book_id) {
        flash('error', 'Выберите книгу');
        go($bookFilter ? "copies.php?book_id=$bookFilter" : 'copies.php');
    }

    if ($id) {
        // Режим редактирования: обновляем статус одного экземпляра
        run("UPDATE Book_copies SET book_id=?, status=? WHERE id=?", [$book_id, $status, $id]);
        flash('success', 'Экземпляр обновлён');
    } else {
        // Режим добавления: создаём $count новых экземпляров
        for ($i = 0; $i < $count; $i++) {
            run("INSERT INTO Book_copies (book_id, status) VALUES (?,?)", [$book_id, $status]);
        }
        flash('success', "Добавлено экземпляров: $count");
    }
    
    // После сохранения перенаправляем обратно, сохраняя фильтр по книге
    go($bookFilter ? "copies.php?book_id=$bookFilter" : 'copies.php');
}


if ($action === 'delete' && $id) {
    deleteRecord('Book_copies', $id, 'Экземпляр удалён', 'Нельзя удалить: есть записи о выдаче', 
                 $bookFilter ? "copies.php?book_id=$bookFilter" : 'copies.php');
}

if ($action === 'add' || $action === 'edit') {
    // Загружаем данные экземпляра, если редактируем
    if ($id) {
        $copy = row("SELECT * FROM Book_copies WHERE id=?", [$id]);
        if (!$copy) {
            flash('error', 'Экземпляр не найден');
            go($bookFilter ? "copies.php?book_id=$bookFilter" : 'copies.php');
        }
    } else {
        $copy = ['id' => 0, 'book_id' => $bookFilter, 'status' => 'available'];
    }
    
    $pageTitle = $id ? 'Редактировать экземпляр' : 'Добавить экземпляры';
    pageTop($pageTitle, 'copies');
    echo getFlash();
    
    // Если есть фильтр по книге, ссылка ведёт на copies.php с book_id
    $backUrl = $bookFilter ? "copies.php?book_id=$bookFilter" : 'copies.php';
    breadcrumb([$backUrl => 'Экземпляры', '' => $id ? 'Редактировать' : 'Добавить']);
    
    // Подготавливаем options для выпадающих списков
    $bookOptions = ['' => '— выберите книгу —'];
    foreach ($books as $b) {
        $bookOptions[$b['id']] = $b['title'];
    }
    
    $statusOptions = [
        'available' => 'Доступна',
        'borrowed'  => 'Выдана',
        'damaged'   => 'Повреждена',
        'lost'      => 'Утеряна'
    ];
    
    $fields = [
        ['label'=>'Книга', 'type'=>'select', 'name'=>'book_id', 'value'=>$copy['book_id'], 'required'=>true, 'options'=>$bookOptions, 'full'=>true],
        ['label'=>'Статус', 'type'=>'select', 'name'=>'status', 'value'=>$copy['status'], 'options'=>$statusOptions],
    ];
    
    // При добавлении добавляем поле для количества экземпляров
    if (!$id) {
        $fields[] = ['label'=>'Количество экземпляров (до 50)', 'type'=>'number', 'name'=>'count', 'value'=>1, 'attrs'=>'min="1" max="50"'];
    }
    
    renderForm('', $fields, 'Сохранить', $backUrl);
    pageBottom();
    exit;
}

// Формируем условие WHERE
$where = $bookFilter ? "WHERE bc.book_id = $bookFilter" : '';

// Получаем список экземпляров
$copies = query("
    SELECT bc.*, b.title AS book_title
    FROM Book_copies bc
    JOIN Books b ON bc.book_id = b.id
    $where
    ORDER BY b.title, bc.id
");

// Если есть фильтр по книге, получаем её название для заголовка
if ($bookFilter) {
    $bookName = val("SELECT title FROM Books WHERE id=?", [$bookFilter]);
    $pageTitle = "Экземпляры книги: $bookName";
} else {
    $pageTitle = "Все экземпляры";
}

pageTop($pageTitle, 'copies');
echo getFlash();

// Если есть фильтр по книге, показываем хлебные крошки для навигации
if ($bookFilter) {
    breadcrumb(['books.php' => 'Книги', 'copies.php' => 'Экземпляры', '' => $bookName ?? '']);
}

// Выводим панель инструментов: общее количество и кнопка добавления
$total = count($copies);
?>
<div class="table-card">
    <div class="table-toolbar">
        <a href="copies.php?action=add<?= $bookFilter ? "&book_id=$bookFilter" : '' ?>" class="btn btn-primary btn-sm">Добавить</a>
    </div>
    
    <table class="data-table">
        <thead>
            <tr><th>#</th><th>Книга</th><th>Статус</th><th>Действия</th></tr>
        </thead>
        <tbody>
        <?php if ($copies): foreach ($copies as $c): ?>
            <tr>
                <td class="td-muted"><?= $c['id'] ?></td>
                <td><a href="copies.php?book_id=<?= $c['book_id'] ?>" style="text-decoration:none; color:var(--primary); font-weight:bold;"><?= e($c['book_title']) ?></a></td>
                <td><?= statusLabel($c['status']) ?></td>
                <td style="display:flex;gap:6px">
                    <a href="?action=edit&id=<?= $c['id'] ?><?= $bookFilter ? "&book_id=$bookFilter" : '' ?>" class="btn btn-outline btn-sm">✎</a>
                    <a href="?action=delete&id=<?= $c['id'] ?><?= $bookFilter ? "&book_id=$bookFilter" : '' ?>" class="btn btn-danger btn-sm" 
                       onclick="return confirm('Удалить экземпляр #<?= $c['id'] ?>?')">✕</a>
                    <?php if ($c['status'] === 'available'): ?>
                    <a href="borrows.php?action=add&amp;copy_id=<?= $c['id'] ?>" class="btn btn-primary btn-sm">Выдать</a>
                    <?php endif ?>
                </td>
            </tr>
        <?php endforeach; else: renderEmptyState(4, 'Экземпляров не найдено'); endif; ?>
        </tbody>
    </table>
</div>

<?php pageBottom(); ?>

